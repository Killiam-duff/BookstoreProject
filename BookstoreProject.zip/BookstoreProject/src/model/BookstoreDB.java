/**
 *
 * @author liamk
 */
import java.sql.*;
//import java.util.HashMap;

public class BookstoreDB {
    public static void main(String[] args) throws Exception {
        String url = "jdbc:sqlserver://localhost:1434;instanceName=SQLEXPRESS;databaseName=Bookstore;encrypt=false";
        String user = "sa";  
        String password = "Magical.88";  

        Connection con = DriverManager.getConnection(url, user, password);
        Statement st = con.createStatement();

        // Drop tables to prevent conflicts (Order: dependent tables first)
        String[] dropStatements = {
            "DROP TABLE IF EXISTS student_book_tr;",
            "DROP TABLE IF EXISTS Inventory;",
            "DROP TABLE IF EXISTS Book;",
            "DROP TABLE IF EXISTS Category;",
            "DROP TABLE IF EXISTS Author;",
            "DROP TABLE IF EXISTS Student;"
        };
        for (String sql : dropStatements) {
            st.executeUpdate(sql);
        }

        // Create the tables
        st.executeUpdate("CREATE TABLE Category (category_id INT PRIMARY KEY, category_name VARCHAR(100))");
        st.executeUpdate("CREATE TABLE Author (author_id INT PRIMARY KEY, author_name VARCHAR(100))");
        st.executeUpdate("CREATE TABLE Student (student_id INT PRIMARY KEY, student_name VARCHAR(100))");

        // Create Book table in correct order
        st.executeUpdate("CREATE TABLE Book ("
                + "book_id INT PRIMARY KEY, "
                + "title VARCHAR(100), "
                + "author_id INT, "
                + "category_id INT, "
                + "FOREIGN KEY(author_id) REFERENCES Author(author_id), "
                + "FOREIGN KEY(category_id) REFERENCES Category(category_id))");

        // Create the tables that are dependent
        st.executeUpdate("CREATE TABLE Inventory (book_id INT PRIMARY KEY, Quantity INTEGER, FOREIGN KEY(book_id) REFERENCES Book(book_id))");
        st.executeUpdate("CREATE TABLE student_book_tr ("
                + "transaction_id INT PRIMARY KEY, "
                + "student_id INT, "
                + "book_id INT, "
                + "FOREIGN KEY(student_id) REFERENCES Student(student_id), "
                + "FOREIGN KEY(book_id) REFERENCES Book(book_id))");

        // Insert data
        st.executeUpdate("INSERT INTO Category VALUES (1, 'Programming'), (2, 'Database')");
        st.executeUpdate("INSERT INTO Author VALUES (1, 'John Doe'), (2, 'Jane Smith')");
        st.executeUpdate("INSERT INTO Student VALUES (1, 'Alice Johnson'), (2, 'Bob Williams')");

        // Insert books after ensuring author_id and category_id exist
        st.executeUpdate("INSERT INTO Book (book_id, title, author_id, category_id) VALUES "
                + "(1, 'Introduction to Java', 1, 1), "
                + "(2, 'Database Fundamentals', 2, 2)");

        // Insert into Inventory and Transactions
        st.executeUpdate("INSERT INTO Inventory VALUES (1, 50), (2, 30)");
        st.executeUpdate("INSERT INTO student_book_tr VALUES (101, 1, 1), (102, 2, 2)");

        System.out.println("✅ Bookstore database created successfully with given data.");

        st.close();
        con.close();
    }
}



